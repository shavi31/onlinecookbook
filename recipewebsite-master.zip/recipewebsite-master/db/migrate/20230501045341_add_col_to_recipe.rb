class AddColToRecipe < ActiveRecord::Migration[7.0]
  def change
    add_column :recipes, :posted_by, :integer
    add_column :recipes, :approved_by, :integer

    add_foreign_key "recipes", "users", column: :posted_by
    add_foreign_key "recipes", "users", column: :approved_by
  end
end