class CreatePreparations < ActiveRecord::Migration[7.0]
  def change
    create_table :preparations do |t|
      t.text :steps
      t.integer :cooking_time
      t.integer :serving_size
      t.references :recipe, null: false, foreign_key: true

      t.timestamps
    end
  end
end
