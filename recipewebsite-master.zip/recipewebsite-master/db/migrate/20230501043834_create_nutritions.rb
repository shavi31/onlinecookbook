class CreateNutritions < ActiveRecord::Migration[7.0]
  def change
    create_table :nutritions do |t|
      t.integer :calories
      t.float :protein
      t.float :fat
      t.references :recipe, null: false, foreign_key: true

      t.timestamps
    end
  end
end
