class Review < ApplicationRecord
  belongs_to :recipe
end
