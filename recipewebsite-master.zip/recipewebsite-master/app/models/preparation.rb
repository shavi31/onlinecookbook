class Preparation < ApplicationRecord
  belongs_to :recipe
end
