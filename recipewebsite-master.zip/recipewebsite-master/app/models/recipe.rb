class Recipe < ApplicationRecord
    has_one :preparation
    has_one :nutrition
    has_many :recipe_categories
    has_many :categories, through: :recipe_categories
    has_many :recipe_tags
    has_many :reviews
    has_many :recipe_ingredients
    has_many :ingredients, through: :recipe_ingredients
    has_many :tags, through: :recipe_tags
    accepts_nested_attributes_for :preparation, reject_if: :all_blank, allow_destroy: true
    accepts_nested_attributes_for :recipe_categories, reject_if: :all_blank, allow_destroy: true
    accepts_nested_attributes_for :recipe_ingredients, reject_if: :all_blank, allow_destroy: true
    accepts_nested_attributes_for :recipe_tags, reject_if: :all_blank, allow_destroy: true
    accepts_nested_attributes_for :nutrition, reject_if: :all_blank, allow_destroy: true
    accepts_nested_attributes_for :reviews, reject_if: :all_blank, allow_destroy: true
end
