class Nutrition < ApplicationRecord
  belongs_to :recipe
end
