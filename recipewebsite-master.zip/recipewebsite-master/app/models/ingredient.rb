class Ingredient < ApplicationRecord
end
