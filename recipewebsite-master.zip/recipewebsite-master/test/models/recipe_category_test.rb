require "test_helper"

class RecipeCategoryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
