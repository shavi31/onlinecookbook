require "test_helper"

class RecipeTagTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
