require "test_helper"

class PreparationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
