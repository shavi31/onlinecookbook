              ___
clk __________|   |_____
               ___
q[1]   ________|   |____
       |       |   |
q[0] __|_______|___|__

Count       00  00  00
* Configuration

* Database creation

* Database initialization

* How to run the test suite

* Services (job queues, cache servers, search engines, etc.)

* Deployment instructions

* ...
